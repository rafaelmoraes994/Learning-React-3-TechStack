import data from './LibraryList.json'

export default () => data
